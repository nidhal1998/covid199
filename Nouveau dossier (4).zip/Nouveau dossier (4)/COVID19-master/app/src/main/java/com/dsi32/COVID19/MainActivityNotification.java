package com.dsi32.COVID19;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivityNotification extends AppCompatActivity {
    ImageView IM1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        IM1 = findViewById(R.id.imag);
        IM1.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivityNotification.this,MainActivity.class);
            startActivity(intent);
        });
    }
}